/*function to go back one page*/
function toAutoPage() {
  location.replace("auto.html")
}

/*function to go forward one page*/
function toEndgamePage() {
  location.replace("endgame.html")
}
